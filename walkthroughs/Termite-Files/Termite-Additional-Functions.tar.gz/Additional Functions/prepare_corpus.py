#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import os

def tab2space(the_str):
    return the_str.replace("\t", " ").replace("\x00", "")

def PrepareCorpus(file_path, output_dir):
    print('--------------------------------------------------------------------------------')
    print(' Preparing corpus.txt and corpus.db...')
    print("   file_path = %s" % (file_path))
    print("  output_dir = %s" % (output_dir))
    print('--------------------------------------------------------------------------------')
    
    print("Reading input file...")
    inf = open(file_path,'r')
    inlines = inf.readlines()
    inf.close()
    
    print("Counting lines...")
    y = len(str(len(inlines)))
    y = format(y, '02')
    
    print("Preparing lines...")
    inlines = list(map(tab2space, inlines))
    outlines = ['%s	%s' % (format(i+1, y), txtline) for i, txtline in enumerate(inlines)]
        
    print("Preparing output files...")
    outf = open(os.path.join(output_dir, 'corpus', 'corpus.txt'),'w')
    outf.writelines(str("".join(outlines)))
    outf.close()
    
    open(os.path.join(output_dir, 'corpus', 'corpus.db'), 'a').close()
    
    print("Completed.")

def main():
    parser = argparse.ArgumentParser(description = 'Prepares a Termite corpus.txt file from a .txt file and creates a blank corpus.db file.')
    parser.add_argument('file_path' , type = str , help = 'A .txt file.')
    parser.add_argument('output_dir' , type = str , help = 'The output directory containing a subdirectory /corpus/.')
    args = parser.parse_args()
    PrepareCorpus(args.file_path, args.output_dir)

if __name__ == '__main__':
	main()
