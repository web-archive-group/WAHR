#!/bin/bash

corpus_name="$1"
corpus_name_safe="${corpus_name// /_}"
corpus_file="$2"
data_dir=${3-"./data/$corpus_name_safe"}

echo 'Creating directory for corpus data (if it does not exist)...'
mkdir -p ./data
mkdir -p "$data_dir"

echo ''
echo "prepare_corpus.py $corpus_file $data_dir"
echo ''
mkdir -p "$data_dir/corpus"
python ./bin/prepare_corpus.py "$corpus_file" "$data_dir"

echo ''
echo "import_corpus.py $data_dir/corpus $data_dir/corpus/corpus.txt"
echo ''
python ./bin/import_corpus.py "$data_dir/corpus" "$data_dir/corpus/corpus.txt"

echo ''
echo "train_mallet.py $data_dir/corpus $data_dir/model-mallet"
echo ''
python ./bin/train_mallet.py "$data_dir/corpus" "$data_dir/model-mallet"

echo ''
echo "read_mallet.py \"$1\" $data_dir/model-mallet $data_dir/corpus $data_dir/corpus"
echo ''
python ./bin/read_mallet.py "$corpus_name" "$data_dir/model-mallet" "$data_dir/corpus" "$data_dir/corpus"