#!/bin/bash

echo "python web2py/web2py.py --nogui -p 8075"
python web2py/web2py.py --nogui -p 8075
